#Name: Hamza Sheikh 
# An externsion of Rock Paper Scissors created with the Tkinter Module
# Based on the game from The Big Bang Theory

from tkinter import *
from random import randint

#command for the button to enter your move, holds most of the game
def start_game():
    #create global variables to allow program to access them
    global wins
    global losses
    global ties
    global total_games
    
    output=""
    player_move = player_choice.get() #convert radiobutton into a variable
    enemy_choice = randint(1, 5)
    
    #rock
    if enemy_choice == 1: 
        if player_move == "r": # if rock
            player_image.configure(image=rock_img) # change  player image
            enemy_image.configure(image=rock_img) # change enemy image
            output += "It's a tie! Press the button to play again" #adds sentence to output
            ties +=1
            win_outcome_image.configure(image=tie_img) # win outcome image
        if player_move == "p": # if paper
            player_image.configure(image=paper_img)
            enemy_image.configure(image=rock_img) # this is repeated for all possible outcomes
            output+= "Your Paper won against the enemy's rock! Press the button to play again"
            wins += 1
            win_outcome_image.configure(image=win_img)
        if player_move == "s":
            player_image.configure(image=scissors_img)
            enemy_image.configure(image=rock_img)
            output+= "Your Scissors lost against the enemy's rock! Press the button to play again"
            losses += 1
            win_outcome_image.configure(image=lose_img)
        if player_move == "l":
            player_image.configure(image=lizard_img)
            enemy_image.configure(image=rock_img)
            output+= "Your Lizard lost against the enemy's rock! Press the button to play again"
            losses += 1
            win_outcome_image.configure(image=lose_img)
        if player_move == "sp":
            player_image.configure(image=spock_img)
            enemy_image.configure(image=rock_img)
            output+= "Your Spock won against the enemy's rock! Press the button to play again"
            wins += 1
            win_outcome_image.configure(image=win_img)
            
    #paper        
    if enemy_choice == 2:
        if player_move == "r": # if rock
            player_image.configure(image=rock_img) 
            enemy_image.configure(image=paper_img)
            output += "Your Rock lost against the enemy's paper! Press the button to play again"
            losses += 1
            win_outcome_image.configure(image=lose_img)
        if player_move == "p": # if paper
            player_image.configure(image=paper_img)
            enemy_image.configure(image=paper_img)
            output+= "It's a tie! Press the button to play again"
            ties += 1
            win_outcome_image.configure(image=tie_img)
        if player_move == "s": # if scissors
            player_image.configure(image=scissors_img)
            enemy_image.configure(image=paper_img)
            output+= "Your Scissors won against the enemy's paper! Press the button to play again"
            wins += 1
            win_outcome_image.configure(image=win_img)
        if player_move == "l": # if lizard
            player_image.configure(image=lizard_img)
            enemy_image.configure(image=paper_img)
            output+= "Your Lizard won against the enemy's paper! Press the button to play again"
            wins += 1
            win_outcome_image.configure(image=win_img)
        if player_move == "sp": # if spock
            player_image.configure(image=spock_img)
            enemy_image.configure(image=paper_img)
            output+= "Your Spock lost against the enemy's paper! Press the button to play again"
            losses += 1
            win_outcome_image.configure(image=lose_img)
            
    #scissors        
    if enemy_choice == 3:
        if player_move == "r": # if rock
            player_image.configure(image=rock_img) 
            enemy_image.configure(image=scissors_img)
            output += "Your Rock won against the enemy's scissors! Press the button to play again"
            wins += 1
            win_outcome_image.configure(image=win_img)
        if player_move == "p": # if paper
            player_image.configure(image=paper_img)
            enemy_image.configure(image=scissors_img)
            output+= "Your Paper lost against the enemy's scissors! Press the button to play again"
            losses += 1
            win_outcome_image.configure(image=lose_img)
        if player_move == "s": # if scissors
            player_image.configure(image=scissors_img)
            enemy_image.configure(image=scissors_img)
            output+= "It's a tie! Press the button to play again"
            ties += 1
            win_outcome_image.configure(image=tie_img)
        if player_move == "l": # if lizard
            player_image.configure(image=lizard_img)
            enemy_image.configure(image=scissors_img)
            output+= "Your Lizard lost against the enemy's scissors! Press the button to play again"
            losses += 1
            win_outcome_image.configure(image=lose_img)
        if player_move == "sp": # if spock
            player_image.configure(image=spock_img)
            enemy_image.configure(image=scissors_img)
            output+= "Your Spock won against the enemy's scissors! Press the button to play again"
            wins += 1
            win_outcome_image.configure(image=win_img)
    # lizard
    if enemy_choice == 4:
        if player_move == "r": # if rock
            player_image.configure(image=rock_img) 
            enemy_image.configure(image=lizard_img)
            output += "Your Rock won against the enemy's lizard! Press the button to play again"
            wins += 1
            win_outcome_image.configure(image=win_img)
        if player_move == "p": # if paper
            player_image.configure(image=paper_img)
            enemy_image.configure(image=lizard_img)
            output+= "Your Paper lost against the enemy's lizard! Press the button to play again"
            losses += 1
            win_outcome_image.configure(image=lose_img)
        if player_move == "s": # if scissors
            player_image.configure(image=scissors_img)
            enemy_image.configure(image=lizard_img)
            output+= "Your Scissors won against the enemy's lizard! Press the button to play again"
            wins += 1
            win_outcome_image.configure(image=win_img)
        if player_move == "l": # if lizard
            player_image.configure(image=lizard_img)
            enemy_image.configure(image=lizard_img)
            output+= "It's a tie! Press the button to play again"
            ties += 1
            win_outcome_image.configure(image=tie_img)
        if player_move == "sp": # if spock
            player_image.configure(image=spock_img)
            enemy_image.configure(image=lizard_img)
            output+= "Your Spock lost against the enemy's lizard! Press the button to play again"
            ties += 1
            win_outcome_image.configure(image=lose_img)
    # spock
    if enemy_choice == 5: 
        if player_move == "r": # if rock
            player_image.configure(image=rock_img) 
            enemy_image.configure(image=spock_img)
            output += "Your Rock lost against the enemy's spock! Press the button to play again"
            losses += 1
            win_outcome_image.configure(image=lose_img)
        if player_move == "p": # if paper
            player_image.configure(image=paper_img)
            enemy_image.configure(image=spock_img)
            output+= "Your Paper won against the enemy's spock! Press the button to play again"
            wins += 1
            win_outcome_image.configure(image=win_img)
        if player_move == "s": # if scissors
            player_image.configure(image=scissors_img)
            enemy_image.configure(image=spock_img)
            output+= "Your Scissors lost against the enemy's spock! Press the button to play again"
            losses += 1
            win_outcome_image.configure(image=lose_img)
        if player_move == "l": # if lizard
            player_image.configure(image=lizard_img)
            enemy_image.configure(image=spock_img)
            output+=  "Your Lizard won against the enemy's spock! Press the button to play again"
            wins += 1
            win_outcome_image.configure(image=win_img)
        if player_move == "sp": # if spock
            player_image.configure(image=spock_img)
            enemy_image.configure(image=spock_img)
            output+= "It's a tie! Press the button to play again"
            ties += 1
            win_outcome_image.configure(image=tie_img)
    #makes sure user has clicked an option
    if player_move not in ["r", "p", "s", "l", "sp"]:
        output += "please choose an option!"
    #if input is correct, these variables will update
    else:
        total_games +=1
        win_display.configure(text="Wins: " + str(wins))
        lose_display.configure(text="Losses: " + str(losses))
        tie_display.configure(text="Ties: " + str(ties))
        total_game_display.configure(text="Total Games: " + str(total_games))
    
    # will delete all previous text and insert the output
    outputer.delete(0.0, END) 
    outputer.insert(0.0, output)

def main():
    
    #create the window
    window = Tk()
    window.resizable(False, False)
    window.title("RPSLS")

    #add variables for wins losses and ties
    wins = 0
    losses = 0
    ties = 0
    total_games = 0

    #variable meant for the radio buttons
    player_choice = StringVar() 

    # all of the radio buttons
    Rock = Radiobutton(window, text='Rock', value="r", variable=player_choice)
    Paper = Radiobutton(window, text='Paper', value="p", variable=player_choice)
    Scissors = Radiobutton(window, text='Scissors', value="s", variable=player_choice)
    Lizard = Radiobutton(window, text='Lizard', value="l", variable=player_choice)
    Spock = Radiobutton(window, text='Spock', value="sp", variable=player_choice)

    #button to start game
    Move_button = Button(window, text="Enter Move", width=60, height=2, command=start_game)

    # add all images
    rock_img = PhotoImage(file="Rock.png")
    paper_img = PhotoImage(file="Paper.png")
    scissors_img = PhotoImage(file="Scissors.png")
    lizard_img = PhotoImage(file="Lizard.png")
    spock_img = PhotoImage(file="Spock.png")
    blank_img = PhotoImage(file="blank_image.png") #blank image will be used when nothing wants to be printed
    win_img = PhotoImage(file="win_image.png")
    lose_img = PhotoImage(file="lose_image.png")
    tie_img = PhotoImage(file="tie_image.png")

    #put images into Labels for where they will be placed
    player_image = Label(window, image=blank_img)
    enemy_image = Label(window, image=blank_img)
    win_outcome_image = Label(window)

    # add the 5 radio buttons and move button
    Rock.grid(row=0, column=0)
    Paper.grid(row=0, column=1)
    Scissors.grid(row=0, column=2)
    Lizard.grid(row=0, column=3)
    Spock.grid(row=0, column=4)
    Move_button.grid(row=1, column=0, columnspan=5)

    #add the text outputer
    outputer = Text(window, width=50, height=5, wrap=WORD)
    outputer.grid(row=2, column=0, columnspan=5)

    #create win, loss and tie Label
    win_display = Label(window, text="Wins: " + str(wins))
    lose_display = Label(window, text="Losses: " + str(losses))
    tie_display =  Label(window, text="Ties: " + str(ties))
    total_game_display = Label(window, text="Total Games: " + str(total_games))

    win_display.grid(row=4, column=0)
    lose_display.grid(row=4, column=1)
    tie_display.grid(row=4, column=2)
    total_game_display.grid(row=4, column=3)

    #place where the images will be stored
    player_image.grid(row=3, column=0)
    enemy_image.grid(row=3, column=4)
    win_outcome_image.grid(row=3, column=2)

    window.mainloop()

if __name__ == '__main__':
    main()